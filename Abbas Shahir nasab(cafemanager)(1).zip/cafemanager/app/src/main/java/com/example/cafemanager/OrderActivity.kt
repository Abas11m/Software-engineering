package com.example.cafemanager

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class OrderActivity : AppCompatActivity() {

    private lateinit var tvProductName: TextView
    private lateinit var tvProductPrice: TextView
    private lateinit var ivProductImage: ImageView
    private lateinit var etQuantity: EditText
    private lateinit var btnOrder: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order)

        tvProductName = findViewById(R.id.tvProductName)
        tvProductPrice = findViewById(R.id.tvProductPrice)
        ivProductImage = findViewById(R.id.ivProductImage)
        etQuantity = findViewById(R.id.etQuantity)
        btnOrder = findViewById(R.id.btnOrder)

        val productName = intent.getStringExtra("productName")
        val productPrice = intent.getStringExtra("productPrice")
        val productImageUri = intent.getParcelableExtra<Uri>("productImageUri")

        tvProductName.text = productName
        tvProductPrice.text = productPrice
        ivProductImage.setImageURI(productImageUri)

        btnOrder.setOnClickListener {
            val quantity = etQuantity.text.toString()
            val orderSummary = "سفارش شما: $productName - تعداد: $quantity - قیمت واحد: $productPrice"
            val resultIntent = Intent()
            resultIntent.putExtra("orderSummary", orderSummary)
            setResult(Activity.RESULT_OK, resultIntent)
            finish()
        }
    }
}
