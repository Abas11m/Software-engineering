package com.example.cafemanager

import android.app.Activity
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

class AddItemActivity : AppCompatActivity() {

    private lateinit var etProductName: EditText
    private lateinit var etProductPrice: EditText
    private lateinit var ivProductImage: ImageView
    private lateinit var btnSelectImage: Button
    private lateinit var btnSave: Button
    private lateinit var btnDelete: Button
    private var selectedImageUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_item)

        etProductName = findViewById(R.id.etProductName)
        etProductPrice = findViewById(R.id.etProductPrice)
        ivProductImage = findViewById(R.id.ivProductImage)
        btnSelectImage = findViewById(R.id.btnSelectImage)
        btnSave = findViewById(R.id.btnSave)
        btnDelete = findViewById(R.id.btnDelete)

        btnSelectImage.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK)
            intent.type = "image/*"
            startActivityForResult(intent, 1)
        }

        btnSave.setOnClickListener {
            val productName = etProductName.text.toString()
            val productPrice = etProductPrice.text.toString()

            if (productName.isNotEmpty() && productPrice.isNotEmpty() && selectedImageUri != null) {
                val imageFileName = saveImageToInternalStorage(selectedImageUri!!)
                if (imageFileName != null) {
                    saveItemToPreferences(productName, productPrice, imageFileName)
                    Toast.makeText(this, "محصول ذخیره شد", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    Toast.makeText(this, "خطا در ذخیره‌سازی تصویر", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "لطفاً تمامی فیلدها را پر کنید", Toast.LENGTH_SHORT).show()
            }
        }

        btnDelete.setOnClickListener {
            showDeleteConfirmationDialog()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == Activity.RESULT_OK) {
            selectedImageUri = data?.data
            ivProductImage.setImageURI(selectedImageUri)
        }
    }

    private fun saveImageToInternalStorage(uri: Uri): String? {
        return try {
            val inputStream: InputStream? = contentResolver.openInputStream(uri)
            val fileName = "product_${System.currentTimeMillis()}.png"
            val file = File(filesDir, fileName)
            val outputStream = FileOutputStream(file)
            val buffer = ByteArray(1024)
            var length: Int
            while (inputStream!!.read(buffer).also { length = it } > 0) {
                outputStream.write(buffer, 0, length)
            }
            outputStream.close()
            inputStream.close()
            fileName
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun saveItemToPreferences(name: String, price: String, imageFileName: String) {
        val sharedPreferences = getSharedPreferences("CafeManagerPrefs", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val gson = Gson()
        val json = sharedPreferences.getString("itemList", null)
        val itemListType = object : com.google.gson.reflect.TypeToken<MutableList<Triple<String, String, String?>>>() {}.type
        val itemList: MutableList<Triple<String, String, String?>> = if (json != null) {
            gson.fromJson(json, itemListType)
        } else {
            mutableListOf()
        }
        itemList.add(Triple(name, price, imageFileName))
        val updatedJson = gson.toJson(itemList)
        editor.putString("itemList", updatedJson)
        editor.apply()
    }

    private fun showDeleteConfirmationDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("حذف تمام محصولات")
        builder.setMessage("آیا مطمئن هستید که می‌خواهید تمام محصولات را حذف کنید؟")
        builder.setPositiveButton("بله") { dialog, _ ->
            deleteAllItems()
            Toast.makeText(this, "تمام محصولات حذف شدند", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }
        builder.setNegativeButton("خیر") { dialog, _ ->
            dialog.dismiss()
        }
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }

    private fun deleteAllItems() {
        val sharedPreferences = getSharedPreferences("CafeManagerPrefs", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.remove("itemList")
        editor.apply()
    }
}
