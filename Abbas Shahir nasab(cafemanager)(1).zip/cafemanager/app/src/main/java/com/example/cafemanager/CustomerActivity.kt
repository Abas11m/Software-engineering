package com.example.cafemanager

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import java.io.File

class CustomerActivity : AppCompatActivity() {

    private lateinit var llProductList: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_customer)

        llProductList = findViewById(R.id.itemContainer)

        loadItemsFromPreferences()
    }

    private fun loadItemsFromPreferences() {
        val sharedPreferences = getSharedPreferences("CafeManagerPrefs", Context.MODE_PRIVATE)
        val gson = Gson()
        val json = sharedPreferences.getString("itemList", null)
        val itemListType = object : com.google.gson.reflect.TypeToken<MutableList<Triple<String, String, String?>>>() {}.type
        val itemList: MutableList<Triple<String, String, String?>> = if (json != null) {
            gson.fromJson(json, itemListType)
        } else {
            mutableListOf()
        }

        itemList.forEach { item ->
            addItemToView(item.first, item.second, item.third)
        }
    }

    private fun addItemToView(name: String, price: String, imageFileName: String?) {
        val itemView = layoutInflater.inflate(R.layout.item_product, llProductList, false)

        val tvProductName = itemView.findViewById<TextView>(R.id.tvProductName)
        val tvProductPrice = itemView.findViewById<TextView>(R.id.tvProductPrice)
        val ivProductImage = itemView.findViewById<ImageView>(R.id.ivProductImage)

        tvProductName.text = name
        tvProductPrice.text = "قیمت : $price تومان"

        if (imageFileName != null) {
            val imageFile = File(filesDir, imageFileName)
            if (imageFile.exists()) {
                ivProductImage.setImageURI(Uri.fromFile(imageFile))
            }
        }

        itemView.setOnClickListener {
            val intent = Intent(this, OrderActivity::class.java)
            intent.putExtra("productName", name)
            intent.putExtra("productPrice", price)
            if (imageFileName != null) {
                intent.putExtra("productImageUri", Uri.fromFile(File(filesDir, imageFileName)))
            }
            startActivity(intent)
        }

        llProductList.addView(itemView)
    }
}
