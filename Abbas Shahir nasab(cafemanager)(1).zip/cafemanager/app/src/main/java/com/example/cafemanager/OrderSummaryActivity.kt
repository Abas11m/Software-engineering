package com.example.cafemanager

import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class OrderSummaryActivity : AppCompatActivity() {

    private lateinit var orderContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_summary)

        orderContainer = findViewById(R.id.orderContainer)

        val orders = intent.getStringArrayListExtra("orders")
        if (orders != null) {
            for (order in orders) {
                addOrderToView(order)
            }
        }
    }

    private fun addOrderToView(orderSummary: String) {
        val textView = TextView(this)
        textView.text = orderSummary
        orderContainer.addView(textView)
    }
}
